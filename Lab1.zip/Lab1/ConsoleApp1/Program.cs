﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            class Program

        {

            static void Main(string[] args)

            {

                //demo_sınıf.Tutorial a = new Tutorial();

                //a.SetTutorial(36, "damla");



                OgrenciSistemi ogrenci = new OgrenciSistemi();

                ogrenci.ogrencisim("Mert");

                ogrenci.numaragirme(2016280017);

                ogrenci.dersalma("2005");

                ogrenci.dersalma("2006");

                ogrenci.dersalma("2007");

                ogrenci.dersalma("2008");

                ogrenci.dersalma("2009");

                ogrenci.dersalma("2010");

                ogrenci.dersalma("2001");



            }

        }

    }
}
    }
}
