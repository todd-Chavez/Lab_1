﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Collections;

namespace ClassLibrary1
{
    public class Class1
    {
        int ogrenciNo;

        string ad;

        ArrayList ogrenciders = new ArrayList();

        static int derssayisi = 6;

        public void numara(int No)

        {

            ogrenciNo = No;

            Console.WriteLine(ogrenciNo);



        }

        public void ogrenciAd(string OgrenciAdi)

        {

            ad = OgrenciAdi;

            Console.WriteLine(ad);

        }

        public void dersSecimi(string derskodu)

        {

            if (derssayisi > 0)

            {

                ogrenciders.Add(derskodu);

                Console.WriteLine(derskodu);

                derssayisi--;

            }

            else

            {

                Console.WriteLine("Kontenjan dolmuştur!");

            }



        }





    }

}
    

