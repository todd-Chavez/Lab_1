﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
                ClassLibrary1.Class1 Ogrenci = new ClassLibrary1.Class1();

                Ogrenci.ogrenciAd("Damla");

                Ogrenci.numara(2016280047);
        
                Ogrenci.dersSecimi("2009");
                Ogrenci.dersSecimi("2010");
                Ogrenci.dersSecimi("2011");
                Ogrenci.dersSecimi("2012");
                Ogrenci.dersSecimi("2013");
                Ogrenci.dersSecimi("2014");
                Ogrenci.dersSecimi("2015");



            }

        }

    }
}
    

